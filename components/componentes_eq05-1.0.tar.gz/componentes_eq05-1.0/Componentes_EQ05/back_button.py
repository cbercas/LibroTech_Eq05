from PySide6.QtWidgets import QPushButton
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtCore import QSize

class BackButton(QPushButton):
    def __init__(self, image_path, button_size=QSize(20, 20), parent=None):
        super().__init__(parent)

        # Establecer el tamaño del botón
        self.setFixedSize(button_size)

        # Cargar la imagen y establecerla como ícono del botón
        self.setIcon(QIcon(QPixmap(image_path)))
        self.setIconSize(button_size)

        # Estilizar el botón (sin borde y fondo transparente)
        self.setStyleSheet("""
            QPushButton {
                border: none;
                background-color: transparent;
            }
            QPushButton:hover {
                background-color: rgba(0, 0, 0, 0.05);
                border-radius: 12px;
            }
            QPushButton:pressed {
                background-color: rgba(0, 0, 0, 0.1);
                border-radius: 12px;
            }
        """)