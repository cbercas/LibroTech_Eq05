from PySide6.QtWidgets import QWidget, QLineEdit, QHBoxLayout
from PySide6.QtCore import Signal


class SearchBar(QWidget):
    # Señal personalizada que se emite cuando se realiza una búsqueda
    search_submitted = Signal(str)

    def __init__(self, placeholder_text="El Don Quijote...", parent=None):
        super().__init__(parent)
        
        # Ajustar tamaño del SearchBar
        self.setFixedSize(220, 30)
        
        # Crear el campo de entrada de texto
        self.search_input = QLineEdit(self)
        self.search_input.setPlaceholderText(placeholder_text)
        self.search_input.setStyleSheet("""
            QLineEdit {
                padding: 4px;
                font-family: "Arial";
                font-size: 14px;
                color: #4A3D2D;
                border: 1px solid rgba(0, 0, 0, 0.5);
                border-radius: 5px;
                background-color: rgba(255, 255, 255, 0.7);
            }
            QLineEdit:focus {
                border: 1px solid #C69C8D;
                background-color: rgba(255, 255, 255, 1);
            }
        """)
        self.search_input.returnPressed.connect(self.on_search)

        # Layout para el widget
        layout = QHBoxLayout()
        layout.addWidget(self.search_input)
        layout.setContentsMargins(0, 0, 0, 0)
        self.setLayout(layout)

    def on_search(self):
        text = self.search_input.text().strip()
        if text:
            self.search_submitted.emit(text)
            self.search_input.clear()