from setuptools import setup, find_packages

setup(
    name="Componentes_EQ05",
    version="1.0",
    description="Componentes personalizados con PySide6",
    author="Equipo_05",
    packages=find_packages(),
    install_requires=["PySide6"],
)
